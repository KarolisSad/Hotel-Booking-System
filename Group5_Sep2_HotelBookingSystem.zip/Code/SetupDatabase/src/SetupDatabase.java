public class SetupDatabase
{
  public static void main(String[] args)
  {
    SimpleConsoleView consoleView = new SimpleConsoleView();
  }
}
