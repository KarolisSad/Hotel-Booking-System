import javafx.application.Application;

public class Client
{
  public static void main(String[] args)
  {
    Application.launch(MyApplication.class);
  }
}

