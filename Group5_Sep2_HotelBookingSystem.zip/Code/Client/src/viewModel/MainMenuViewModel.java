package viewModel;

import model.Model;

public class MainMenuViewModel
{

    private Model model;

    public MainMenuViewModel(Model model) {
        this.model = model;
    }

}