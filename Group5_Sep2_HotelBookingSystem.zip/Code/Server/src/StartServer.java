import mediator.HotelServer;
import model.Model;
import model.ModelManager;

public class StartServer {
    public static void main(String[] args) {
        SimpleConsoleView consoleView = new SimpleConsoleView();
    }
}
